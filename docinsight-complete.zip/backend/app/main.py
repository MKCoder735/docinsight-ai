
from fastapi import FastAPI
from app.routes import documents
app=FastAPI(title='DocInsight AI')
app.include_router(documents.router,prefix='/api')
