
from fastapi import APIRouter, UploadFile, File
import pandas as pd
router=APIRouter()

@router.post('/summarize')
async def summarize(file: UploadFile = File(...)):
    text=(await file.read()).decode('utf-8',errors='ignore')
    s=' '.join(text.split()[:120])
    return {'summary': s}

@router.post('/analyze-csv')
async def analyze(file: UploadFile = File(...)):
    df=pd.read_csv(file.file)
    return {'rows':len(df),'columns':len(df.columns),'columns_list':list(df.columns)}
