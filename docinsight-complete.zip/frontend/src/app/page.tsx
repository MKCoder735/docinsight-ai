
export default function Home(){
 return (
  <main>
   <h1>DocInsight AI</h1>
   <p>Free document summarizer and CSV analyzer.</p>
  </main>
 )
}
